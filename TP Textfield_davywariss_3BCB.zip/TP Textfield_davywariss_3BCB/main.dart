import 'package:flutter/material.dart';

void main() {
  runApp(TextFieldExamplesApp());
}

class TextFieldExamplesApp extends StatelessWidget {
  const TextFieldExamplesApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('TextField Examples')),

        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            FilledTextFieldExample(),

            OutlinedTextFieldExample(),
          ],
        ),
      ),
    );
  }
}

class FilledTextFieldExample extends StatelessWidget {
  const FilledTextFieldExample({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(8.0),
      child: TextField(
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.search),
          suffixIcon: Icon(Icons.clear),
          labelText: 'Filled',
          hintText: 'hint text',
          helperText: 'supporting text',
          filled: true,
        ),
      ),
    );
  }
}

class OutlinedTextFieldExample extends StatelessWidget {
  const OutlinedTextFieldExample({super.key});

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(8.0),
      child: TextField(
        decoration: InputDecoration(
          prefixIcon: Icon(Icons.search),
          suffixIcon: Icon(Icons.clear),
          labelText: 'Outlined',
          hintText: 'hint text',
          helperText: 'supporting text',
          border: OutlineInputBorder(),
        ),
      ),
    );
  }
}
