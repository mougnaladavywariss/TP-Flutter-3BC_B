import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      title: 'MyApp',
      home: MyHomePage(),
      debugShowCheckedModeBanner: false,
    ),
  );
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _textFieldController = TextEditingController();

  void _navigateToResultPage(BuildContext context) {
    String value = _textFieldController.text;
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ResultPage(value: value)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.menu),
        title: Text('My Home Page'),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.settings)),
          IconButton(onPressed: () {}, icon: Icon(Icons.tab_sharp)),
          IconButton(onPressed: () {}, icon: Icon(Icons.search)),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _textFieldController,
              decoration: InputDecoration(labelText: 'Entrez du texte'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _navigateToResultPage(context),
              child: Text('Valider'),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultPage extends StatelessWidget {
  final String value;

  ResultPage({required this.value});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Result Page')),
      body: Center(child: Text('Data from TextField: $value')),
    );
  }
}
