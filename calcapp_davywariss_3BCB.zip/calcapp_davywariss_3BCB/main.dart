import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculatrice Débutant',
      debugShowCheckedModeBanner: false,
      home: CalculatorPage(),
    );
  }
}

class CalculatorPage extends StatefulWidget {
  @override
  _CalculatorPageState createState() => _CalculatorPageState();
}

class _CalculatorPageState extends State<CalculatorPage> {
  final TextEditingController _displayController = TextEditingController();

  double _num1 = 0;
  double _num2 = 0;
  String _operation = '';
  double _resultat = 0;

  void _ajouterChiffre(String chiffre) {
    setState(() {
      _displayController.text += chiffre;
    });
  }

  void _setOperation(String op) {
    setState(() {
      _num1 = double.tryParse(_displayController.text) ?? 0;
      _operation = op;
      _displayController.clear();
    });
  }

  void _calculerResultat() {
    setState(() {
      _num2 = double.tryParse(_displayController.text) ?? 0;

      if (_operation == '+') {
        _resultat = _num1 + _num2;
      } else if (_operation == '-') {
        _resultat = _num1 - _num2;
      } else if (_operation == '*') {
        _resultat = _num1 * _num2;
      } else if (_operation == '/') {
        if (_num2 == 0) {
          _resultat = 0;
        } else {
          _resultat = _num1 / _num2;
        }
      }

      _displayController.text = _resultat.toString();
    });
  }

  void _effacer() {
    setState(() {
      _displayController.clear();
      _num1 = 0;
      _num2 = 0;
      _operation = '';
      _resultat = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calculatrice Simple')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _displayController,
              readOnly: true,
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                hintText: '0',
              ),
            ),
            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('1'),
                  child: const Text('1', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('2'),
                  child: const Text('2', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('3'),
                  child: const Text('3', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _setOperation('+'),
                  child: const Text('+', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),
            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('4'),
                  child: const Text('4', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('5'),
                  child: const Text('5', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('6'),
                  child: const Text('6', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _setOperation('-'),
                  child: const Text('-', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),
            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('7'),
                  child: const Text('7', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('8'),
                  child: const Text('8', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('9'),
                  child: const Text('9', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: () => _setOperation('*'),
                  child: const Text('×', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),
            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _ajouterChiffre('0'),
                  child: const Text('0', style: TextStyle(fontSize: 20)),
                ),
                ElevatedButton(
                  onPressed: _effacer,
                  child: const Text(
                    'C',
                    style: TextStyle(fontSize: 20, color: Colors.red),
                  ),
                ),
                ElevatedButton(
                  onPressed: _calculerResultat,
                  child: const Text(
                    '=',
                    style: TextStyle(fontSize: 20, color: Colors.green),
                  ),
                ),
                ElevatedButton(
                  onPressed: () => _setOperation('/'),
                  child: const Text('÷', style: TextStyle(fontSize: 20)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
